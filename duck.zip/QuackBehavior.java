public interface QuackBehavior{
  public void quack();
}