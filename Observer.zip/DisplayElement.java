package Observer;

public interface DisplayElement {
	public void display();
}
